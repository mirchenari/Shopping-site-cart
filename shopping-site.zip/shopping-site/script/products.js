let url = "https://shopping-cart-h5u7tvjyy-sahebmohammadi.vercel.app/";

export const products = [
    {
        id: 1,
        title: "queen panel bed",
        price: 10.99,
        imageUrl: url + "images/product-1.jpeg",
    },
    {
        id: 2,
        title: "saheb panel bed",
        price: 14.99,
        imageUrl: url + "images/product-2.jpeg",
    },
    {
        id: 3,
        title: "folan panel bed",
        price: 7.99,
        imageUrl: url + "images/product-3.jpeg",
    },
    {
        id: 4,
        title: "twin panel bed",
        price: 11.99,
        imageUrl: url + "images/product-4.jpeg",
    },
    {
        id: 5,
        title: "fridge",
        price: 4.99,
        imageUrl: url + "images/product-5.jpeg",
    },
    {
        id: 6,
        title: "fridge",
        price: 23.99,
        imageUrl: url + "images/product-6.jpeg",
    },
    {
        id: 7,
        title: "dresser",
        price: 42.99,
        imageUrl: url + "images/product-7.jpeg",
    },
    {
        id: 8,
        title: "couch",
        price: 24.99,
        imageUrl: url + "images/product-8.jpeg",
    },
];